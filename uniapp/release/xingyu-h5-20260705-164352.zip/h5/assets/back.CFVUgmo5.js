const a="/static/images/bg-login.png",t="/static/native/back.png";export{a as _,t as a};
