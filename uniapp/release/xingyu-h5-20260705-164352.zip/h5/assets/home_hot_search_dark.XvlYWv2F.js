const t="/static/native/home_hot_search_dark.png";export{t as _};
