const t="/static/native/homehot_message.png";export{t as _};
