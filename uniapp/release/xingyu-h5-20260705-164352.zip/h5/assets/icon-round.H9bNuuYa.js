const n="/static/brand/icon-round.webp";export{n as _};
