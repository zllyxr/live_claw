const s="/static/images/sports-header.png";export{s as _};
