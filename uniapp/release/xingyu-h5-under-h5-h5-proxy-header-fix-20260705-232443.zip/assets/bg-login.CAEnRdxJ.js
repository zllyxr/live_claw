const g="/h5/static/images/bg-login.png";export{g as _};
