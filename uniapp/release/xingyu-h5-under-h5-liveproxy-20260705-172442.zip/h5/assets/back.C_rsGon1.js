const a="/h5/static/images/bg-login.png",t="/h5/static/native/back.png";export{a as _,t as a};
