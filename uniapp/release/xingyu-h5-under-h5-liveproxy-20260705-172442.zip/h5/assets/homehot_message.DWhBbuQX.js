const t="/h5/static/native/homehot_message.png";export{t as _};
