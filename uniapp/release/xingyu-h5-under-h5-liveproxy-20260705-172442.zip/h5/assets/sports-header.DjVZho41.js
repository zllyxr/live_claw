const s="/h5/static/images/sports-header.png";export{s as _};
